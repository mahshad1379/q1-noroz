#!/usr/bin/env python
# coding: utf-8

# In[17]:


import math
PI = math.pi
class Circle:
    def __init__(self , shoa):
        self.shoa = shoa
        
    def getArea(self):
        area = PI*self.shoa**2
        return area
    
    def getPerimeter(self):
        perimeter = 2*PI*self.shoa
        return perimeter
    


# In[18]:


c = Circle(11)
c.getArea()


# In[19]:


c = Circle(4.44)
c.getPerimeter()


# In[7]:


c.__dict__


# In[ ]:




