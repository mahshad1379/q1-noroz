#!/usr/bin/env python
# coding: utf-8

# In[16]:


class Calculator:
    def __init__(self):
        pass
                
    def add(self , num1 , num2):
        return num1 + num2
    def subtract(self , num1 , num2):
        return num1 - num2
    def multiply(self , num1 , num2):
        return num1 * num2
    def divide(self , num1 , num2):
        return num1 // num2


# In[17]:


calculator = Calculator()


# In[18]:


calculator.add(10, 5)


# In[19]:


calculator.subtract(10, 5)


# In[20]:


calculator.multiply(10, 5)


# In[21]:


calculator.divide(10, 5)


# In[ ]:




