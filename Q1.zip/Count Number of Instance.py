#!/usr/bin/env python
# coding: utf-8

# In[1]:


class User:
    user_count = 0
    def __init__(self , username):
        self.username = username
        User.user_count = User.user_count + 1
        


# In[2]:


u1 = User("johnsmith10")
User.user_count


# In[3]:


u2 = User("marysue1989")
User.user_count


# In[ ]:


u1.__dict__


# In[ ]:


User.__dict__


# In[ ]:




