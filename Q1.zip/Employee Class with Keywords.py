#!/usr/bin/env python
# coding: utf-8

# In[2]:


class Employee:
    def __init__(self , fullname, **kwargs ):
        self.fullname = fullname
        self.name , self.lastname = fullname.split()
        self.__dict__.update(kwargs)


# In[ ]:




