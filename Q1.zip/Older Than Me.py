#!/usr/bin/env python
# coding: utf-8

# In[51]:


class Person:
    def __init__(self , name , age):
        self.name = name
        self.age = age
        
    def compare_age(self , another):
        if self.age > another.age:
            print("{} is younger than me.".format(another.name))
        elif self.age < another.age:
            print("{} is older than me.".format(another.name)) 
        elif self.age == another.age:
            print("{} is the same age as me.".format(another.name))        


# In[ ]:





# In[52]:


p2.compare_age(p1)


# In[53]:


p1.compare_age(p2)


# In[54]:


p1.compare_age(p3)


# In[ ]:





# In[ ]:




