#!/usr/bin/env python
# coding: utf-8

# In[42]:


class Employee:
    def __init__(self , firstname , lastname):
        self.firstname = firstname
        self.lastname = lastname
        
        self.fullname = firstname + " " + lastname
        self.email = firstname.lower() +"."+lastname.lower() + "@company.com"
    


# In[43]:


emp_1 = Employee("John", "Smith")
emp_2 = Employee("Mary",  "Sue")
emp_3 = Employee("Antony", "Walker")


# In[44]:


emp_1.fullname


# In[45]:


emp_2.email


# In[46]:


emp_3.firstname


# In[47]:





# In[ ]:




