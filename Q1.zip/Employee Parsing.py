#!/usr/bin/env python
# coding: utf-8

# In[67]:


class Employee:
    def __init__(self , _firstname , _lastname  ,_salary ):
        self.firstname = _firstname
        self.lastname = _lastname
        self.salary = _salary
    @staticmethod
    def from_string(_string):
        _firstname , _lastname , _salary =  _string.split('-')
        return Employee(_firstname , _lastname , int(_salary)

    
    
    


# In[65]:


emp1 = Employee("Mary", "Sue", 60000)


# In[61]:


emp1.firstname


# In[62]:


emp1.salary


# In[63]:


emp2 = Employee.from_string("John-Smith-55000")


# In[57]:


emp2.firstname


# In[ ]:




